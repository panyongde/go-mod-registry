package model

import "errors"

var (
	ErrNoRow = errors.New("no rows in result set")
)
