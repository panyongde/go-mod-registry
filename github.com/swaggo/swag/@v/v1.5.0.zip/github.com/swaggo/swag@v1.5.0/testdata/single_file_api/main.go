package main

// @title Swagger Example API
// @version 1.0
// @description This is a sample server Petstore server.
// @description It has a lot of beautiful features.
// @termsOfService http://swagger.io/terms/

// @Summary test op
// @Router /test [get]
// @Description This belongs to the operation, not the general API!
func op() bool {
	return true
}
