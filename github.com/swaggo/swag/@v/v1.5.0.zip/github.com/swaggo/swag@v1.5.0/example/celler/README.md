# Celler example

Gen doc

```console
$ go get -u github.com/swaggo/swag/cmd/swag
$ swag init
```

Run app

```console
$ go run main.go
```

[open swagger](http://localhost:8080/swagger/index.html)

