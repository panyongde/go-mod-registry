/*
Package swag converts Go annotations to Swagger Documentation 2.0.
See https://github.com/swaggo/swag for more information about swag.
*/
package swag // import "github.com/swaggo/swag"
